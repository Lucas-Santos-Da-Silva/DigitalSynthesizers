![GitHub License](https://img.shields.io/github/license/Lucas-Santos-Da-Silva/DigitalSynthesizers)
![Website](https://img.shields.io/website?url=https%3A%2F%2Flucas-santos-da-silva.github.io%2FDigitalSynthesizers%2F)
![W3C Validation](https://img.shields.io/w3c-validation/html?targetUrl=https%3A%2F%2Flucas-santos-da-silva.github.io%2FDigitalSynthesizers%2F)
<p>
<a href="http://jigsaw.w3.org/css-validator/check/referer">
    <img style="border:0;width:88px;height:31px"
        src="http://jigsaw.w3.org/css-validator/images/vcss-blue"
        alt="CSS válido!" />
    </a>
</p>

# DigitalSynthesizers
Este repositório hospeda o projeto do site DigitalSynthesizers
## Autor
Lucas Santos da Silva
## Links utilizados


[Google Trends]https://trends.google.com/trends/

[Google Fonts]https://fonts.google.com/

[Validator W3]https://validator.w3.org/

[draw.io]https://app.diagrams.net/

[Icon Finder]https://www.iconfinder.com/

[Pixabay]https://pixabay.com/pt/

[Image Compressor]https://imagecompressor.com/

[Github Shield]https://shields.io
